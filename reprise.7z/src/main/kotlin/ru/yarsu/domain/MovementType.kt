package ru.yarsu.domain

enum class MovementType {
    ADDITION, REMOVAL
}
