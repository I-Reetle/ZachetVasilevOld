package ru.yarsu.domain

import java.util.UUID

data class Product(
    val id: UUID,
    val name: String,
)
